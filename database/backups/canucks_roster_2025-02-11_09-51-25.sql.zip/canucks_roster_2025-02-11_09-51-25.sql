-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: canucks_roster
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draft_teams`
--

DROP TABLE IF EXISTS `draft_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draft_teams` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draft_teams`
--

LOCK TABLES `draft_teams` WRITE;
/*!40000 ALTER TABLE `draft_teams` DISABLE KEYS */;
INSERT INTO `draft_teams` VALUES (1,1,'2024-09-09 07:44:47','2024-09-09 07:44:47'),(2,2,'2024-09-10 08:20:00','2024-09-10 08:20:00'),(3,3,'2024-09-10 12:28:19','2024-09-10 12:28:19'),(4,7,'2024-09-10 12:33:45','2024-09-10 12:33:45'),(5,8,'2024-09-10 12:35:56','2024-09-10 12:35:56'),(6,10,'2024-09-10 12:40:34','2024-09-10 12:40:34'),(7,12,'2024-09-10 12:44:15','2024-09-10 12:44:15'),(8,14,'2024-09-10 12:48:49','2024-09-10 12:48:49'),(9,15,'2024-09-10 12:49:35','2024-09-10 12:49:35'),(10,16,'2024-09-10 13:02:45','2024-09-10 13:02:45'),(11,17,'2024-09-10 13:04:20','2024-09-10 13:04:20'),(12,6,'2024-09-10 13:05:53','2024-09-10 13:05:53'),(13,19,'2024-09-10 13:10:37','2024-09-10 13:10:37'),(14,21,'2024-09-10 13:12:53','2024-09-10 13:12:53'),(15,22,'2024-09-10 13:16:04','2024-09-10 13:16:04'),(16,23,'2024-09-10 13:18:10','2024-09-10 13:18:10'),(17,25,'2024-10-03 06:57:49','2024-10-03 06:57:49'),(18,24,'2024-10-03 07:07:57','2024-10-03 07:07:57'),(19,29,'2024-10-09 10:01:14','2024-10-09 10:01:14'),(20,11,'2024-11-11 15:49:16','2024-11-11 15:49:16'),(21,26,'2025-02-11 08:26:44','2025-02-11 08:26:44');
/*!40000 ALTER TABLE `draft_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (12,'0001_01_01_000000_create_users_table',1),(13,'0001_01_01_000001_create_cache_table',1),(14,'0001_01_01_000002_create_jobs_table',1),(15,'2024_05_01_115437_create_players_table',1),(16,'2024_05_01_130157_create_positions_table',1),(17,'2024_05_01_130405_create_nationalities_table',1),(18,'2024_05_01_130435_create_teams_table',1),(19,'2024_05_01_141334_create_player_previous_team_table',1),(20,'2024_05_02_090628_create_personal_access_tokens_table',1),(21,'2024_05_02_131721_create_draft_teams_table',1),(22,'2024_05_02_132921_create_previous_teams_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nationalities`
--

DROP TABLE IF EXISTS `nationalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nationalities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nationalities`
--

LOCK TABLES `nationalities` WRITE;
/*!40000 ALTER TABLE `nationalities` DISABLE KEYS */;
INSERT INTO `nationalities` VALUES (1,'USA','2024-09-09 07:44:47','2024-09-09 07:44:47'),(2,'Sweden','2024-09-10 12:29:36','2024-09-10 12:29:36'),(3,'Switzerland','2024-09-10 12:32:28','2024-09-10 12:32:28'),(4,'Finland','2024-09-10 12:33:45','2024-09-10 12:33:45'),(5,'Canada','2024-09-10 12:35:56','2024-09-10 12:35:56'),(6,'Belarus','2024-09-10 12:38:35','2024-09-10 12:38:35'),(7,'Latvia','2024-09-10 12:40:34','2024-09-10 12:40:34'),(8,'Czechia','2024-09-10 13:05:53','2024-09-10 13:05:53'),(9,'Netherlands','2024-10-03 07:05:08','2024-10-03 07:05:08');
/*!40000 ALTER TABLE `nationalities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_previous_team`
--

DROP TABLE IF EXISTS `player_previous_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_previous_team` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint(20) unsigned NOT NULL,
  `previous_team_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_previous_team`
--

LOCK TABLES `player_previous_team` WRITE;
/*!40000 ALTER TABLE `player_previous_team` DISABLE KEYS */;
INSERT INTO `player_previous_team` VALUES (1,2,1,NULL,NULL),(2,3,2,NULL,NULL),(3,3,3,NULL,NULL),(4,5,4,NULL,NULL),(5,5,5,NULL,NULL),(6,6,6,NULL,NULL),(7,7,7,NULL,NULL),(8,7,8,NULL,NULL),(9,7,2,NULL,NULL),(10,10,9,NULL,NULL),(11,10,10,NULL,NULL),(12,12,11,NULL,NULL),(13,15,12,NULL,NULL),(14,16,13,NULL,NULL),(15,16,14,NULL,NULL),(16,17,5,NULL,NULL),(17,21,15,NULL,NULL),(18,21,16,NULL,NULL),(19,23,17,NULL,NULL),(20,23,9,NULL,NULL),(21,25,18,NULL,NULL),(22,25,12,NULL,NULL),(23,26,19,NULL,NULL),(24,26,20,NULL,NULL),(25,26,18,NULL,NULL),(26,30,21,NULL,NULL),(27,30,22,NULL,NULL),(28,30,9,NULL,NULL),(29,31,1,NULL,NULL),(30,32,9,NULL,NULL),(31,32,22,NULL,NULL),(32,32,23,NULL,NULL),(33,32,14,NULL,NULL),(34,32,5,NULL,NULL),(35,33,20,NULL,NULL),(36,33,24,NULL,NULL),(37,33,12,NULL,NULL),(38,33,21,NULL,NULL),(39,34,22,NULL,NULL),(40,34,25,NULL,NULL),(41,34,8,NULL,NULL),(42,35,21,NULL,NULL),(43,36,26,NULL,NULL),(44,37,4,NULL,NULL),(45,37,8,NULL,NULL),(46,39,19,NULL,NULL),(47,42,2,NULL,NULL),(48,43,9,NULL,NULL),(49,44,22,NULL,NULL),(50,44,9,NULL,NULL);
/*!40000 ALTER TABLE `player_previous_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `jersey_number` tinyint(3) unsigned NOT NULL,
  `position_id` bigint(20) unsigned NOT NULL,
  `date_of_birth` date NOT NULL,
  `nationality_id` bigint(20) unsigned NOT NULL,
  `draft_team_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `players_jersey_number_unique` (`jersey_number`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (1,'Brock Boeser',6,1,'1997-02-25',1,1,'2024-09-09 07:44:47','2024-09-09 07:44:47',NULL),(2,'Conor Garland',8,1,'1996-03-11',1,2,'2024-09-10 08:20:00','2024-09-10 08:24:05',NULL),(4,'Nils Hoglander',21,2,'2000-12-20',2,1,'2024-09-10 12:29:36','2024-09-10 12:29:36',NULL),(5,'Pius Suter',24,3,'1996-05-24',3,NULL,'2024-09-10 12:32:28','2024-09-10 12:32:28',NULL),(6,'Aatu Raty',54,3,'2002-11-14',4,4,'2024-09-10 12:33:45','2025-02-11 07:49:54','2025-02-11 07:49:54'),(7,'Phillip Di Giuseppe',34,2,'1993-10-09',5,5,'2024-09-10 12:35:56','2024-10-07 09:29:27','2024-10-07 09:29:27'),(8,'Elias Pettersson',40,3,'1998-11-12',2,1,'2024-09-10 12:37:20','2024-09-10 12:37:20',NULL),(9,'Danila Klimovich',46,1,'2003-01-09',6,1,'2024-09-10 12:38:35','2024-10-03 07:10:38','2024-10-03 07:10:38'),(10,'Teddy Blueger',53,3,'1994-08-15',7,6,'2024-09-10 12:40:34','2024-09-10 12:40:34',NULL),(11,'Arshdeep Bains',13,2,'2001-01-09',5,NULL,'2024-09-10 12:42:04','2024-10-09 10:04:48','2024-10-09 10:04:48'),(12,'Dakota Joshua',81,3,'1996-05-15',1,7,'2024-09-10 12:44:15','2025-02-11 08:22:25',NULL),(13,'Nils Aman',88,3,'2000-02-07',2,8,'2024-09-10 12:48:49','2024-11-11 15:52:29','2024-11-11 15:52:29'),(14,'Linus Karlsson',94,3,'1999-11-16',2,9,'2024-09-10 12:49:35','2024-10-03 07:12:28','2024-10-03 07:12:28'),(16,'Carson Soucy',7,4,'1994-07-27',5,11,'2024-09-10 13:04:20','2024-09-10 13:04:20',NULL),(17,'Filip Hronek',17,4,'1997-11-02',8,12,'2024-09-10 13:05:53','2024-09-10 13:05:53',NULL),(18,'Akito Hirose',41,4,'1999-04-09',5,NULL,'2024-09-10 13:06:49','2024-10-07 09:32:59','2024-10-07 09:32:59'),(19,'Quinn Hughes',43,4,'1999-10-14',1,1,'2024-09-10 13:08:00','2024-09-10 13:08:00',NULL),(21,'Noah Juulsen',47,4,'1997-04-02',5,13,'2024-09-10 13:10:37','2024-09-10 13:10:37',NULL),(22,'Cole McWard',48,4,'2001-06-09',1,NULL,'2024-09-10 13:11:31','2024-10-03 07:14:42','2024-10-03 07:14:42'),(24,'Guillaume Brisebois',55,4,'1997-07-21',5,1,'2024-09-10 13:14:33','2024-10-03 07:16:50','2024-10-03 07:16:50'),(25,'Tyler Myers',57,4,'1990-02-01',1,15,'2024-09-10 13:16:04','2024-09-10 13:16:04',NULL),(26,'Christian Wolanin',86,4,'1995-03-17',5,16,'2024-09-10 13:18:10','2024-10-07 09:34:00','2024-10-07 09:34:00'),(27,'Arturs Silovs',31,5,'2001-03-22',7,1,'2024-09-10 13:19:33','2024-11-11 15:55:22','2024-11-11 15:55:22'),(28,'Thatcher Demko',35,5,'1995-12-08',1,1,'2024-09-10 13:20:26','2025-02-11 08:27:37',NULL),(29,'Nikita Tolopilo',60,5,'2000-04-06',6,NULL,'2024-09-10 13:21:29','2024-10-03 07:18:10','2024-10-03 07:18:10'),(31,'Nate Smith',83,3,'1998-10-19',1,10,'2024-10-03 07:01:54','2024-10-07 09:35:31','2024-10-07 09:35:31'),(33,'Derek Forbort',27,4,'1992-03-04',1,18,'2024-10-03 07:07:57','2024-10-03 07:07:57',NULL),(34,'Kiefer Sherwood',44,2,'1995-03-31',1,NULL,'2024-10-09 09:55:30','2024-10-09 09:55:30',NULL),(35,'Jake DeBrusk',74,2,'1996-10-17',5,17,'2024-10-09 09:58:20','2024-10-09 09:58:20',NULL),(37,'Kevin Lankinen',32,5,'1995-04-28',4,NULL,'2024-10-09 10:03:23','2024-10-09 10:03:23',NULL),(38,'Jonathan Lekkerimaki',23,1,'2004-07-24',2,1,'2024-11-11 15:46:25','2025-02-11 07:53:19','2025-02-11 07:53:19'),(41,'Ty Young',85,5,'2004-09-11',5,1,'2025-02-11 07:56:13','2025-02-11 07:56:31','2025-02-11 07:56:31'),(42,'Filip Chytil',72,3,'1999-09-05',8,3,'2025-02-11 07:59:51','2025-02-11 07:59:51',NULL),(43,'Drew O\'Connor',18,2,'1998-06-09',1,NULL,'2025-02-11 08:24:17','2025-02-11 08:24:17',NULL),(44,'Marcus Pettersson',29,4,'1996-05-08',2,21,'2025-02-11 08:26:44','2025-02-11 08:26:44',NULL);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'Right wing','2024-09-09 07:44:47','2024-09-09 07:44:47'),(2,'Left wing','2024-09-10 08:21:32','2024-09-10 08:21:32'),(3,'Center','2024-09-10 12:28:19','2024-09-10 12:28:19'),(4,'Defense','2024-09-10 13:02:45','2024-09-10 13:02:45'),(5,'Goaltender','2024-09-10 13:19:33','2024-09-10 13:19:33');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `previous_teams`
--

DROP TABLE IF EXISTS `previous_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `previous_teams` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `previous_teams`
--

LOCK TABLES `previous_teams` WRITE;
/*!40000 ALTER TABLE `previous_teams` DISABLE KEYS */;
INSERT INTO `previous_teams` VALUES (1,2,'2024-09-10 08:20:00','2024-09-10 08:20:00'),(2,3,'2024-09-10 12:28:19','2024-09-10 12:28:19'),(3,4,'2024-09-10 12:28:19','2024-09-10 12:28:19'),(4,5,'2024-09-10 12:32:28','2024-09-10 12:32:28'),(5,6,'2024-09-10 12:32:28','2024-09-10 12:32:28'),(6,7,'2024-09-10 12:33:45','2024-09-10 12:33:45'),(7,8,'2024-09-10 12:35:56','2024-09-10 12:35:56'),(8,9,'2024-09-10 12:35:56','2024-09-10 12:35:56'),(9,10,'2024-09-10 12:40:34','2024-09-10 12:40:34'),(10,11,'2024-09-10 12:40:34','2024-09-10 12:40:34'),(11,13,'2024-09-10 12:44:15','2024-09-10 12:44:15'),(12,16,'2024-09-10 13:02:45','2024-09-10 13:02:45'),(13,17,'2024-09-10 13:04:20','2024-09-10 13:04:20'),(14,18,'2024-09-10 13:04:20','2024-09-10 13:04:20'),(15,19,'2024-09-10 13:10:37','2024-09-10 13:10:37'),(16,20,'2024-09-10 13:10:37','2024-09-10 13:10:37'),(17,21,'2024-09-10 13:12:53','2024-09-10 13:12:53'),(18,22,'2024-09-10 13:16:04','2024-09-10 13:16:04'),(19,23,'2024-09-10 13:18:10','2024-09-10 13:18:10'),(20,24,'2024-09-10 13:18:10','2024-09-10 13:18:10'),(21,25,'2024-10-03 06:57:49','2024-10-03 06:57:49'),(22,26,'2024-10-03 06:57:49','2024-10-03 06:57:49'),(23,27,'2024-10-03 07:05:08','2024-10-03 07:05:08'),(24,28,'2024-10-03 07:07:57','2024-10-03 07:07:57'),(25,14,'2024-10-09 09:55:30','2024-10-09 09:55:30'),(26,29,'2024-10-09 10:01:14','2024-10-09 10:01:14');
/*!40000 ALTER TABLE `previous_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1YYC9iD62y6vqiCJ7Axctu917R2lrr0toWViSBAo',NULL,'193.160.246.142','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRzc5eklQNXVBbnBMTDdEeThOWlF0TEpWeUhTNGhQWWJQdkVHYzdBVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739216872),('4D7jg6RXeHg1ismx8hIvN7EwYxKMoO3tf09HmHnl',NULL,'167.71.175.236','Mozilla/5.0 (Linux; Android 6.0; HTC One M9 Build/MRA9789) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.5104.98 Mobile Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoieTVXdWhnWlRoMjVsbVgzdG5VSTVWWTFZY1picVRqSlVpMU8xaXY4TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739009682),('4qe7HweK5ewPuZL05Tjv69pdqJtbgKarLPbRbwKR',NULL,'64.226.78.121','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFVDZE9CRFlpczJoTUsyM1lQaWZ6Yk5EbTAxM2hTeHJ0NTZyNktyVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738839792),('539HmTQ6czFUvPKjME0DJUfX5jOqAsMVPL10KlBg',NULL,'54.195.3.232','Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066','YTozOntzOjY6Il90b2tlbiI7czo0MDoibDM0N2ZhUGhKSmFhdG1nbGpSZlhaRWF4NHRsdVk3WmE2dkN0Y2NDaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739216544),('dkbg7cQtSBh4faaT9rGXIDzzbqIGToZXh9OY9qza',NULL,'193.160.246.142','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoib1U4RGp5SjhKV2MwOVU5Ynd2NTB6WUhsNDFvSGRKSDFCdG12TkFsNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739260080),('EbCplBxynfQ4s9Rn3yG1n8Zeb38dem5g3wMQyTzH',NULL,'93.22.148.12','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR0ZlclRaSGM4NTVYdGFMbEFnc1hxVEFqbkp2Um1TOEVSQzZLTnJvaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738785378),('H5lDF7VK4gx4lNVBPwonReP7XDqr6HHqdcDA87eu',NULL,'45.10.153.217','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSENpVlkwNUJqNk9jZ05lMUIxVGxldGd6MlA0UlFFSGk1bUJQaFFpYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739033319),('hp1d0xyLcybw7JQmxpP1F1bNNqst15uAJHLMgwSm',NULL,'206.189.2.13','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTh5ZzZSNEswQTd1UW9DMzJRb2tCYnAyU28ySExSVmVwNWUxWDI5TSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738680309),('I6kWt0L9gQRVgjYZiHo89H9NMolLZtNwISSWqA2h',NULL,'199.45.155.80','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoib3FnNG5uMHpRUlQzTHc1eG9KQ1JSakQzQkF5dWJvODR2TTVJQ01YTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739199555),('Jyt1joH2CnIjfVVvA3UutU2yROgRlnDeB6O9addj',NULL,'167.71.175.236','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlhNbUZ3WnVnNWZYc21ObmY5UGdaQVdXQWNURGduY1Z0ZTFwWWc2MyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739009679),('lBdFc8Swrd8qApHAteKfhcRNNTPvLuqBGsBYP6w1',NULL,'64.226.78.121','Mozilla/5.0 (Linux; Android 6.0; HTC One M9 Build/MRA9789) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.5104.98 Mobile Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYk05QmFTUzU0WmdpSXduaTFXd2lyZ25ndThKYUU4ZHkxY25PMVlvNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738839792),('MMsLW36b4IlcvT8nypBCJDHxpMtI2pm17yiaoci4',NULL,'167.71.66.240','Mozilla/5.0 (compatible)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibEZsbVo3MDJ1dGdsenlGbVhUY1BhWlRPQ3A1NFBFazB3S1NCUHZ6ZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738816479),('MyNWQ1DXz5qfyT6xxVvnFtFIwdImI57cx6gSbtzV',NULL,'64.226.78.121','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVDhkUm5QSDhzQUl4QXRRaDNQQ08yVmJqRlBRZkdQN2ZJaWxHeE5hZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsvP3Jlc3Rfcm91dGU9JTJGd3AlMkZ2MiUyRnVzZXJzJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1738839796),('nDiDuUG2a8IG4n4lxx6ITL92x48nYJjDDI7nMdrs',NULL,'206.189.2.13','Mozilla/5.0 (Linux; Android 6.0; HTC One M9 Build/MRA9789) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.5104.98 Mobile Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoienVFc2dIRFBiU0FhcHdsb2dnS1RjVjFhdWNXRVhxaXlHTE5zdEpxRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1738680310),('p2SWfLuF9DctCC0t0C3vYHPp7lqLxGj9yaAoEUyu',NULL,'206.189.2.13','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0w3cjdMZ0RQbEs4Nk56dUZzWHNrQklweHVzclBtOFoydDI5UzB6YSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsvP3Jlc3Rfcm91dGU9JTJGd3AlMkZ2MiUyRnVzZXJzJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1738680313),('r2yrZvUdwurVSu9FNbCwq2yBCUs3h7OidcDte6D8',NULL,'104.152.52.63','curl/7.61.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoickRqeGhvZlpkWklwY21mVVBmNmtJUVFUb0JuajBxUVJLaEY2ZlZ4eCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739148607),('t2RPtckktpzzxtp0eqWzo9gFeJ7vFDmPiwQTN9HT',NULL,'143.244.168.161','','YTozOntzOjY6Il90b2tlbiI7czo0MDoicDRJRUtlZGZqdk52Z2V1ZUh2b3NLaDRCMWpSbzhYUWxTRldoV3VaWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739183693),('WaDRIoR2NIqAhbY8gDN52yug6ywheIMbMKlKsmzW',NULL,'143.244.168.161','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2JwTnUxUXRYQnE3eWFTRWRKQzQxTWF6cnBUTjE1M0hVYTBKN0hRdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsvP3Jlc3Rfcm91dGU9JTJGd3AlMkZ2MiUyRnVzZXJzJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1739183704),('WfcXSh6h2x10SyVfNCsdEuoSXx61x3ZhUjfwNEfH',NULL,'167.71.175.236','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoibHYySjFQWjZwQjFTczFIck5kczR5eWlHbkZRUTZtU0NSOU5wTTNHVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsvP3Jlc3Rfcm91dGU9JTJGd3AlMkZ2MiUyRnVzZXJzJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1739009690),('WH1UjJOj43p5FPdWqQf5yAgsMdbg9UvspiHUSwG0',NULL,'167.94.145.104','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRENLNERLcE4xV0R6Z2FmR0E1S0hSSFlYZFFVRFdQQ3d6ZEtwSEhORiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739210828),('zIOF646GGXnDCsbfrsdsbCTaQvGdARKMfx3xVFfW',NULL,'143.244.168.161','Mozilla/5.0 (Linux; Android 6.0; HTC One M9 Build/MRA9789) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.5104.98 Mobile Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMHdEc1ZoMjd1cnRPTUpkVldJbWtGOTNsZE0zNmkwM2pTVHB5eldNMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vY2FudWNrcy1yb3N0ZXItYXBpLjIwMjMtYmVydHIuZGV2LmlvLWFjYWRlbXkudWsiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1739183695);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'Vancouver Canucks','2024-09-09 07:44:47','2024-09-09 07:44:47'),(2,'Arizona Coyotes','2024-09-10 08:20:00','2024-09-10 08:20:00'),(3,'New York Rangers','2024-09-10 12:28:19','2024-09-10 12:28:19'),(4,'Tampa Bay Lightning','2024-09-10 12:28:19','2024-09-10 12:28:19'),(5,'Chicago Blackhawks','2024-09-10 12:32:28','2024-09-10 12:32:28'),(6,'Detroit Red Wings','2024-09-10 12:32:28','2024-09-10 12:32:28'),(7,'New York Islanders','2024-09-10 12:33:45','2024-09-10 12:33:45'),(8,'Carolina Hurricanes','2024-09-10 12:35:56','2024-09-10 12:35:56'),(9,'Nashville Predators','2024-09-10 12:35:56','2024-09-10 12:35:56'),(10,'Pittsburgh Penguins','2024-09-10 12:40:34','2024-09-10 12:40:34'),(11,'Vegas Golden Knights','2024-09-10 12:40:34','2024-09-10 12:40:34'),(12,'Toronto Maple Leafs','2024-09-10 12:44:15','2024-09-10 12:44:15'),(13,'St Louis Blues','2024-09-10 12:44:15','2024-09-10 12:44:15'),(14,'Colorado Avalanche','2024-09-10 12:48:49','2024-09-10 12:48:49'),(15,'San Jose Sharks','2024-09-10 12:49:35','2024-09-10 12:49:35'),(16,'Winnipeg Jets','2024-09-10 13:02:45','2024-09-10 13:02:45'),(17,'Minnesota Wild','2024-09-10 13:04:20','2024-09-10 13:04:20'),(18,'Seattle Kraken','2024-09-10 13:04:20','2024-09-10 13:04:20'),(19,'Montreal Canadiens','2024-09-10 13:10:37','2024-09-10 13:10:37'),(20,'Florida Panthers','2024-09-10 13:10:37','2024-09-10 13:10:37'),(21,'Philadelphia Flyers','2024-09-10 13:12:53','2024-09-10 13:12:53'),(22,'Buffalo Sabres','2024-09-10 13:16:04','2024-09-10 13:16:04'),(23,'Ottawa Senators','2024-09-10 13:18:10','2024-09-10 13:18:10'),(24,'Los Angeles Kings','2024-09-10 13:18:10','2024-09-10 13:18:10'),(25,'Boston Bruins','2024-10-03 06:57:49','2024-10-03 06:57:49'),(26,'Anaheim Ducks','2024-10-03 06:57:49','2024-10-03 06:57:49'),(27,'Washington Capitals','2024-10-03 07:05:08','2024-10-03 07:05:08'),(28,'Calgary Flames','2024-10-03 07:07:57','2024-10-03 07:07:57'),(29,'Edmonton Oilers','2024-10-09 10:01:14','2024-10-09 10:01:14');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'canucks_roster'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-11  8:51:35
